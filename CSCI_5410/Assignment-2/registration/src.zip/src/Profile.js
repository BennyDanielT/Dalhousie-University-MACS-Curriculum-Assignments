import { useState } from 'react';
import './App.css';
import { db } from './firebase-config';
import { collection, doc, getDocs, updateDoc } from 'firebase/firestore';
import { useNavigate, useParams } from 'react-router-dom';

function Profile() {
  // const { loggedInUser, ...others } = props;

  let { loggedInUser } = useParams();

  console.log(loggedInUser);
  const navigate = useNavigate();

  //console.log({ props });

  const [users, setUsers] = useState([]);
  const usersCollectionRef = collection(db, '5410_Users_State');
  const stateCollectionRef = collection(db, '5410_Users_State');

  //Retrieve and render Users who're Online

  const getUsers = async () => {
    const data = await getDocs(usersCollectionRef);
    setUsers(data.docs.map((doc) => ({ ...doc.data(), id: doc.id })));
  };
  getUsers();

  const onlineUsers = users.filter((user) => {
    return user.Status == true; //AND User.name!= loggedInUser
  });

  const listItems = onlineUsers.map((user) => <li>{user.Name}</li>);

  //Logout Function

  const handleLogout = async () => {
    updateFirebase();
    navigate('/Login');
  };

  const updateFirebase = async () => {
    const currentUser = users.filter((user) => {
      return user.Name == loggedInUser;
    });
    const logOffUserDoc = doc(db, '5410_Users_State', currentUser[0].id);
    const onlineStatus = { Status: false };
    await updateDoc(logOffUserDoc, onlineStatus);
  };
  //End of Logout function
  return (
    <div class='pt-20'>
      <h3>Hey There {loggedInUser} !</h3>
      <h1>PROFILE PAGE BROTHAAAA {loggedInUser} !!!!</h1>
      <h1>Users currently logged in !!!!</h1>
      <ul class='list-disc hover:list-disc'>{listItems}</ul>
      <div class='md:flex md:items-center'>
        <div class='md:w-1/3'></div>
        <div class='md:w-2/3'>
          <button
            onClick={handleLogout}
            class='shadow bg-purple-500 hover:bg-purple-400 focus:shadow-outline focus:outline-none text-white font-bold py-2 px-4 rounded'
            // onClick={}
          >
            {' '}
            Logout
          </button>
        </div>
      </div>
    </div>
  );
}

export default Profile;
